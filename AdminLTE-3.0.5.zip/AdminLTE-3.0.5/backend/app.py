import flask
app = flask.Flask(__name__)

@app.route('/')
def hello_world():
    return 'Hello, World!'

@app.route('/rcvLoad')
def rcvLoad():
	print('load rcvd')
	return flask.Response(status=200)


@app.route('/rcvThreshold')
def rcvThresh():
	print('thresh rcvd')
	print(flask.request.args.get("test"))
	return flask.Response(status=200)

app.run(port=8080)